package com.corhuila.app;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    // Usuario de demostracion: admin / admin123 (la clave se guarda con BCrypt)
    private static final String DEMO_USER = "admin";
    private static final String DEMO_PASSWORD = "admin123";

    private final JwtService jwtService;
    private final PasswordEncoder encoder;
    private final String demoHash;

    public AuthController(JwtService jwtService, PasswordEncoder encoder) {
        this.jwtService = jwtService;
        this.encoder = encoder;
        this.demoHash = encoder.encode(DEMO_PASSWORD);
    }

    public record LoginRequest(String username, String password) {}

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        if (DEMO_USER.equals(request.username())
                && request.password() != null
                && encoder.matches(request.password(), demoHash)) {
            return ResponseEntity.ok(Map.of("token", jwtService.generate(request.username())));
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Credenciales inválidas"));
    }
}
