package com.corhuila.app;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final TareaRepository repository;

    public DataLoader(TareaRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        if (repository.count() == 0) {
            repository.save(new Tarea("Configurar JWT en el backend", true));
            repository.save(new Tarea("Consumir la API desde React", true));
            repository.save(new Tarea("Correr la app en Docker", false));
        }
    }
}
