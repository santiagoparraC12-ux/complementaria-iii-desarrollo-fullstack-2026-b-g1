package com.corhuila.app;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class AuthSecurityTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;

    private String loginBody(String user, String pass) {
        return "{\"username\":\"" + user + "\",\"password\":\"" + pass + "\"}";
    }

    @Test
    void loginCorrecto_devuelveToken() throws Exception {
        mvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(loginBody("admin", "admin123")))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.token").exists());
    }

    // ---- Caso de error (backend) ----
    @Test
    void loginConClaveIncorrecta_devuelve401() throws Exception {
        mvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(loginBody("admin", "incorrecta")))
           .andExpect(status().isUnauthorized());
    }

    // ---- Caso de error (backend) ----
    @Test
    void endpointProtegido_sinToken_devuelve401() throws Exception {
        mvc.perform(get("/api/tareas")).andExpect(status().isUnauthorized());
    }

    @Test
    void endpointProtegido_conToken_devuelve200() throws Exception {
        String body = mvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(loginBody("admin", "admin123")))
            .andReturn().getResponse().getContentAsString();
        String token = mapper.readTree(body).get("token").asText();

        mvc.perform(get("/api/tareas").header("Authorization", "Bearer " + token))
           .andExpect(status().isOk());
    }
}
