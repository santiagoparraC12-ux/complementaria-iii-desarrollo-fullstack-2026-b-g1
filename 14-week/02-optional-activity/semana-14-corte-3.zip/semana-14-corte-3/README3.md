# Actividad calificable · Corte 3 — App fullstack segura y probada

**Autor:** SANTIAGO PARRA CADENA · **GitHub:** santiagoparraC12-ux · **Semana 14**

Aplicación fullstack con **Spring Boot** (API REST) y **React + Vite** (frontend).
La API protege sus endpoints con **JWT**, el frontend inicia sesión y consume los
datos protegidos, y todo se puede ejecutar en un contenedor **Docker**.

## Estructura

```
semana-14-corte-3/
├── backend/      API REST (Spring Boot 3, Spring Security, JPA, H2, JWT)
├── frontend/     React + Vite (login + vista de tareas protegida)
├── Dockerfile    Imagen única: compila el frontend y lo sirve desde Spring Boot
└── README.md
```

## Endpoints

| Método | Ruta              | Acceso     | Descripción                          |
|--------|-------------------|------------|--------------------------------------|
| POST   | `/api/auth/login` | Público    | Recibe `username` y `password`, devuelve `{ "token": "..." }` |
| GET    | `/api/tareas`     | Con token  | Lista las tareas                     |
| POST   | `/api/tareas`     | Con token  | Crea una tarea                       |

Usuario de demostración: **admin / admin123**.

## Ejecutar en desarrollo

```bash
# Terminal 1 - backend (http://localhost:8080)
cd backend
./mvnw spring-boot:run        # o: mvn spring-boot:run

# Terminal 2 - frontend (http://localhost:5173)
cd frontend
npm install
npm run dev
```

CORS permite los orígenes `http://localhost:5173` y `http://localhost:3000`.

## Pruebas

```bash
# Backend (JUnit + MockMvc): login correcto, login inválido (401), acceso sin token (401), acceso con token (200)
cd backend && mvn test

# Frontend (Vitest + Testing Library): login inválido muestra error, login válido guarda el token
cd frontend && npm install && npm test -- --run
```

## Docker

```bash
docker build -t app-segura .
docker run -p 8080:8080 -e JWT_SECRET="un-secreto-largo-de-minimo-32-caracteres" app-segura
```

Abrir <http://localhost:8080>.

## Security & run

The API uses JSON Web Tokens (JWT) to authenticate users. A client sends its credentials to `POST /api/auth/login`, and the server answers with a signed token that expires after one hour. The React frontend stores this token and sends it in the `Authorization: Bearer <token>` header on every request to a protected endpoint, while requests without a valid token receive a 401 response. CORS is configured on the backend so that the frontend origin is allowed to call the API during development. The backend tests check a successful login, a rejected login, and a request without a token, and the frontend tests check that an invalid login shows an error message. To run the whole app with Docker, build the image with `docker build -t app-segura .` and start it with `docker run -p 8080:8080 -e JWT_SECRET=<your-secret> app-segura`. The secret must be at least 32 characters long and should never be committed to the repository.

## Versionado

Commits siguiendo el estilo `feat:`, `test:`, `docs:`, `chore:` sobre mi fork del repositorio de la clase,
dentro de la carpeta de la semana correspondiente.
