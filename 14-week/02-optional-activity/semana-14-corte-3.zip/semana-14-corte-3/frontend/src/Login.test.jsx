import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/vitest";
import { vi, test, expect, beforeEach } from "vitest";
import Login from "./Login";

beforeEach(() => {
  localStorage.clear();
});

async function llenarYEnviar(usuario, clave) {
  await userEvent.type(screen.getByPlaceholderText("Usuario"), usuario);
  await userEvent.type(screen.getByPlaceholderText("Contraseña"), clave);
  await userEvent.click(screen.getByRole("button", { name: /entrar/i }));
}

// ---- Caso de error (frontend) ----
test("muestra un error si las credenciales son inválidas", async () => {
  global.fetch = vi.fn().mockResolvedValue({ ok: false, status: 401 });
  render(<Login onSuccess={() => {}} />);

  await llenarYEnviar("admin", "incorrecta");

  expect(await screen.findByRole("alert")).toHaveTextContent("Credenciales inválidas");
  expect(localStorage.getItem("token")).toBeNull();
});

test("guarda el token y avisa al iniciar sesión correctamente", async () => {
  global.fetch = vi.fn().mockResolvedValue({
    ok: true,
    status: 200,
    json: async () => ({ token: "abc123" }),
  });
  const onSuccess = vi.fn();
  render(<Login onSuccess={onSuccess} />);

  await llenarYEnviar("admin", "admin123");

  await vi.waitFor(() => expect(onSuccess).toHaveBeenCalled());
  expect(localStorage.getItem("token")).toBe("abc123");
});
