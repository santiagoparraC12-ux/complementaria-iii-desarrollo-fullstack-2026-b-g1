import { useEffect, useState } from "react";
import { crearTarea, getTareas } from "./api";

export default function Tareas({ onLogout }) {
  const [tareas, setTareas] = useState([]);
  const [titulo, setTitulo] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    getTareas()
      .then(setTareas)
      .catch((err) => {
        setError(err.message);
        if (err.message === "No autorizado") onLogout();
      });
  }, []);

  async function handleAdd(e) {
    e.preventDefault();
    if (!titulo.trim()) return;
    try {
      const nueva = await crearTarea(titulo);
      setTareas([...tareas, nueva]);
      setTitulo("");
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section>
      <div className="row">
        <h1>Mis tareas</h1>
        <button onClick={onLogout}>Salir</button>
      </div>
      {error && <p role="alert">{error}</p>}
      <ul>
        {tareas.map((t) => (
          <li key={t.id} className={t.completada ? "done" : ""}>
            {t.titulo}
          </li>
        ))}
      </ul>
      <form onSubmit={handleAdd}>
        <input
          placeholder="Nueva tarea"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
        />
        <button type="submit">Agregar</button>
      </form>
    </section>
  );
}
