// En desarrollo apunta a http://localhost:8080 (ver .env.development).
// En Docker el frontend se sirve desde el mismo origen que la API.
const API = import.meta.env.VITE_API_URL ?? "";

export function getToken() {
  return localStorage.getItem("token");
}

export function logout() {
  localStorage.removeItem("token");
}

export async function login(username, password) {
  const res = await fetch(`${API}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  if (!res.ok) throw new Error("Credenciales inválidas");
  const { token } = await res.json();
  localStorage.setItem("token", token);
  return token;
}

function authHeaders() {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${getToken()}`,
  };
}

export async function getTareas() {
  const res = await fetch(`${API}/api/tareas`, { headers: authHeaders() });
  if (res.status === 401) throw new Error("No autorizado");
  if (!res.ok) throw new Error("Error al cargar las tareas");
  return res.json();
}

export async function crearTarea(titulo) {
  const res = await fetch(`${API}/api/tareas`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({ titulo, completada: false }),
  });
  if (res.status === 401) throw new Error("No autorizado");
  if (!res.ok) throw new Error("Error al crear la tarea");
  return res.json();
}
