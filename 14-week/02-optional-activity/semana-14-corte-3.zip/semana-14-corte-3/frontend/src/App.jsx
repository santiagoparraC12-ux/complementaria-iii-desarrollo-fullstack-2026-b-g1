import { useState } from "react";
import Login from "./Login";
import Tareas from "./Tareas";
import { getToken, logout } from "./api";

export default function App() {
  const [autenticado, setAutenticado] = useState(!!getToken());

  function handleLogout() {
    logout();
    setAutenticado(false);
  }

  return (
    <main>
      {autenticado ? (
        <Tareas onLogout={handleLogout} />
      ) : (
        <Login onSuccess={() => setAutenticado(true)} />
      )}
    </main>
  );
}
